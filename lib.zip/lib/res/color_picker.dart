import 'dart:ui';

import 'package:flutter/material.dart';

final Color cDarkBlue = Color(0xFF03000F);
final Color cRoyalBlue = Color(0xFF424BE1);

final Color cLightGrey = Color(0xFFBBBDC1);
final Color cDarkGrey = Color(0xff999B9E);
Color cRoyalBlue1 = Color(0xFF3E5AEF);

Color cPurple = Color(0xFF6C0BB9);
final Color cWhite = Colors.white;
final Color cGreen = Color(0XFF2DB80A);

final Color cThemColor = Color(0xFF03000F);
Color cTextLabel = Color(0xFF080A0C);
