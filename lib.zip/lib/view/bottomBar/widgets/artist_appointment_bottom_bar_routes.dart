
import 'package:beuty_app/view/profileTab/appointment/appointment_screen.dart';
import 'package:flutter/material.dart';

Widget artistCameraBottomBarRoutes(
  String route,
) {
  switch (route) {
    case 'AppointmentScreen':
      return AppointmentScreen();
      break;
    default:
      return AppointmentScreen();
      break;
  }
}
