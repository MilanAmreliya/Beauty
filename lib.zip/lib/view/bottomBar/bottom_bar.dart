import 'dart:developer';

import 'package:beuty_app/view/bottomBar/widgets/model_profile_bottom_bar_routrs.dart';
import 'package:beuty_app/viewModel/bottom_bar_viewmodel.dart';
import 'package:beuty_app/viewModel/validation_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'widgets/artist_appointment_bottom_bar_routes.dart';
import 'widgets/artist_explore_bottom_bar_routes.dart';
import 'widgets/artist_home_bottom_bar_routes.dart';
import 'widgets/artist_profile_bottom_bar_routes.dart';
import 'widgets/bottom_navigation_bar.dart';
import 'widgets/model_appointment_bottom_bar_routes.dart';
import 'widgets/model_explore_bottom_bar_routes.dart';
import 'widgets/model_home_bottom_bar_routes.dart';

class BottomBar extends StatefulWidget {
  const BottomBar({Key key}) : super(key: key);

  @override
  _BottomBarState createState() => _BottomBarState();
}

class _BottomBarState extends State<BottomBar> {
  ValidationViewModel _validationViewModel = Get.find();

  @override
  Widget build(BuildContext context) {
    log("modal value${_validationViewModel.selectRole.value}");
    return Material(
      child: Obx(() => Column(
            children: [
              _validationViewModel.selectRole.value == 'Artist'
                  ? Expanded(
                      child: GetBuilder<BottomBarViewModel>(
                        builder: (controller) {
                          return controller.selectedIndex.value == 0
                              ? artistHomeBottomBarRoutes(
                                  controller.selectedRoute.value)
                              : controller.selectedIndex.value == 3
                                  ? artistProfileBottomBarRoutes(
                                      controller.selectedRoute.value)
                                  : controller.selectedIndex.value == 1
                                      ? artistExploreBottomBarRoutes(
                                          controller.selectedRoute.value)
                                      : artistCameraBottomBarRoutes(
                                          controller.selectedRoute.value);
                        },
                      ),
                    )
                  : Expanded(
                      child: GetBuilder<BottomBarViewModel>(
                        builder: (controller) {
                          return controller.selectedIndex.value == 0
                              ? modelHomeBottomBarRoutes(
                                  controller.selectedRoute.value,
                                )
                              : controller.selectedIndex.value == 3
                                  ? modelProfileBottomBarRoutes(
                                      controller.selectedRoute.value)
                                  : controller.selectedIndex.value == 1
                                      ? modelExploreBottomBarRoutes(
                                          controller.selectedRoute.value)
                                      : modelAppointmentBottomBarRoutes(
                                          controller.selectedRoute.value);
                        },
                      ),
                    ),
              bottomNavigationBar(_validationViewModel)
            ],
          )),
    );
  }
}
