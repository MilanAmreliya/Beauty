import 'dart:developer';

import 'package:beuty_app/res/color_picker.dart';
import 'package:beuty_app/sharedPreference/shared_preference.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'authScreen/signup/sign_up_screen.dart';

class WalkingScreen extends StatelessWidget {
  RxInt _selectedPageIndex = 0.obs;

  @override
  Widget build(BuildContext context) {
    log("selectedIndex..${_selectedPageIndex.value}");
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Obx(() => pageIndicator(
                  selectedIndex: _selectedPageIndex.value,
                )),
            PageView(
              children: [
                walkingBody(title: "", image: "p1"),
                walkingBody(title: "", image: "p2"),
                walkingBody(title: "", image: "p3"),
              ],
              onPageChanged: (index) {
                _selectedPageIndex.value = index;
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget walkingBody({String title, String image}) {
    log("Current index${_selectedPageIndex.value}");
    final String path = "assets/image/";

    return Container(
      height: Get.height,
      width: Get.width,
      // color: cThemColor,
      child: Column(
        children: [
          Text("$title"),
          Spacer(),
          Container(
            height: Get.width / 2,
            width: Get.width / 2,
            decoration: BoxDecoration(
                color: cThemColor,
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(
                    fit: BoxFit.fill, image: AssetImage('$path${image}.png'))),
          ),
          Spacer(),
          Obx(() => _selectedPageIndex.value == 2
              ? GestureDetector(
                  onTap: () async {
                    await PreferenceManager.setWalkingScreen(true);
                    Get.off(SignUpScreen());
                    // Get.off(SignIn());
                  },
                  child: Align(
                    alignment: Alignment.bottomRight,
                    child: Container(
                        alignment: Alignment.center,
                        width: Get.width / 4,
                        height: 50,
                        margin: EdgeInsets.only(bottom: 20, right: 20),
                        decoration: BoxDecoration(
                            color: cRoyalBlue,
                            borderRadius: BorderRadius.circular(10),
                            gradient: LinearGradient(colors: [
                              cRoyalBlue1,
                              cPurple,
                            ])),
                        child: Text(
                          "Go",
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w500),
                          textAlign: TextAlign.left,
                        )),
                  ),
                )
              : SizedBox()),
        ],
      ),
    );
  }
}

class pageIndicator extends StatefulWidget {
  final int selectedIndex;

  pageIndicator({Key key, this.selectedIndex}) : super(key: key);

  @override
  _pageIndicatorState createState() => _pageIndicatorState();
}

class _pageIndicatorState extends State<pageIndicator> {
  @override
  Widget build(BuildContext context) {
    return Positioned(
        left: Get.width / 2.6,
        right: Get.width / 2.6,
        bottom: Get.height / 16,
        child: Row(
          children: List.generate(
              3,
              (index) => AnimatedContainer(
                    margin: EdgeInsets.symmetric(horizontal: 5, vertical: 30),
                    height: 10,
                    width: (index == widget.selectedIndex) ? 30 : 10,
                    decoration: BoxDecoration(
                      color: cRoyalBlue,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    duration: Duration(milliseconds: 300),
                  )),
        ));
  }
}
