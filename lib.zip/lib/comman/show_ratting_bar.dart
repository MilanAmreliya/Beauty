import 'package:flutter/material.dart';

Widget showRattingBar() {
  return SizedBox();
  /* return RatingBar.builder(
    initialRating: rating,
    minRating: 1,
    direction: Axis.horizontal,
    allowHalfRating: true,
    itemCount: 5,
    itemSize: Get.height * 0.025,
    unratedColor: Colors.amber.withOpacity(0.3),
    itemBuilder: (context, _) => Icon(
      Icons.star,
      color: Colors.amber,
    ),
    ignoreGestures: true,
    onRatingUpdate: (value) {},
  );*/
}
