import 'package:geolocator/geolocator.dart';

class GetLocation {
  static double latitude = 0.0;
  static double longitude=0.0;

  static Future<void> checkLocationPermission() async {
    LocationPermission locationPermission = await Geolocator.checkPermission();
    if (locationPermission == LocationPermission.denied) {
      locationPermission = await Geolocator.requestPermission();
      if (locationPermission == LocationPermission.denied) {
        locationPermission = await Geolocator.requestPermission();
        await getLatLong();
      } else {
        await getLatLong();
      }
    } else {
      await getLatLong();
    }
  }

  static Future<void> getLatLong() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
    /*  latitude=21.2172638;
      longitude=72.8869927;*/
      latitude = position.latitude;
      longitude = position.longitude;
    } catch (error) {
      print('Geolocator error $error');
    }
  }
}
